import React from 'react'

export default function Footer() {
    return (
        <div className=' bg-amber-300 '>
            Footer / EMS @2025
        </div>
    )
}
