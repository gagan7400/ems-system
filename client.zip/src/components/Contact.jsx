import React from 'react'

export default function Contact() {
    return (
        <div className='h-[90vh] text-[50px] text-center flex justify-center  items-center'>
            <h4> Contact Page     </h4>
        </div>
    )
}
