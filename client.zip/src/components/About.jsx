import React from 'react'

export default function About() {
  return (
    <div className='h-[90vh] text-[50px]  text-center flex justify-center  items-center'>
      <h2> Hello About Page </h2>
    </div>
  )
}
